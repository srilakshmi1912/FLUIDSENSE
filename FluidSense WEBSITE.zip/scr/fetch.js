const firebaseConfig = {
    apiKey: "AIzaSyBRjAp1jqn7HLyRdfjlKBbjaQJmVoP1wkU",
    authDomain: "fluidsense-8c7f3.firebaseapp.com",
    databaseURL: "https://fluidsense-8c7f3-default-rtdb.firebaseio.com",
    projectId: "fluidsense-8c7f3",
    storageBucket: "fluidsense-8c7f3.appspot.com",
    messagingSenderId: "425639321998",
    appId: "1:425639321998:web:cadc8d00108fa4193c04df",
    measurementId: "G-6D8MZ5RFPP"
      
  
};
  
firebase.initializeApp(firebaseConfig);

document.getElementById('checkStatus').addEventListener('submit', submitForm);

function submitForm(e){
    e.preventDefault();
    var patient = document.getElementById("patientID").value;
    firebase.database().ref('messages').on('value',(snap)=>{
        var data = snap.val()
        console.log(data.numChildren())
    });

}